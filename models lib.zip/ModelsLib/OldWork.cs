﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelsLib
{
    class CommonFunc
    {
        public static void AddItem<T>(T[] HighLevelStructure, T LowLovelStructure)
        {
            T[] PseudoHighLevelStructure = new T[HighLevelStructure.Length + 1];
            for (int i = 0; i < HighLevelStructure.Length; i++)
                PseudoHighLevelStructure[i] = HighLevelStructure[i];
            PseudoHighLevelStructure[PseudoHighLevelStructure.Length - 1] = LowLovelStructure;
            HighLevelStructure = PseudoHighLevelStructure;
        }

        public static void DefaultInit<T>(T[] AnyStructure)
        {
            AnyStructure = (T[])Array.CreateInstance(typeof(T), 0);
        }
    }
    public class NewMatrix : IEnumerable
    {
        private Position[] _matrix;

        public NewMatrix()
        {
            
            this._matrix = (Position[])Array.CreateInstance(typeof(Position), 0);
        }

        // новый метод
        public void AddItem(Position[] thisMatrix, Position newPosition)
        {
            CommonFunc.AddItem<Position>(thisMatrix, newPosition);
            

            //Position[] tempMatrix = new Position[thisMatrix.Length + 1];
            //for (int i = 0; i < thisMatrix.Length; i++)
            //    tempMatrix[i] = thisMatrix[i];
            //tempMatrix[tempMatrix.Length - 1] = newPosition;
            //thisMatrix = tempMatrix;
        }


        // старый метод 
        public void AddItem(Position newPosition)
        {
            Position[] tempMatrix = new Position[this._matrix.Length + 1];
            for (int i = 0; i < this._matrix.Length; i++)
                tempMatrix[i] = this._matrix[i];
            tempMatrix[tempMatrix.Length - 1] = newPosition;
            this._matrix = tempMatrix;
        }
        public void RemoveItem(int index)
        {
            if (index >= this._matrix.Length)
                return;

            Position[] tempMatrix = new Position[this._matrix.Length - 1];
            for (int i = 0, j = 0; i < this._matrix.Length; i++, j++)
            {
                if (index == i)
                    j--;
                else
                    tempMatrix[j] = this._matrix[i];
            }
            this._matrix = tempMatrix;
        }

        public void ClearAll()
        {
            //CommonFunc.DefaultInit<NewMatrix>(this._matrix);
            this._matrix = (Position[])Array.CreateInstance(typeof(Position), 0);
        }

        public IEnumerator GetEnumerator()
        {
            return _matrix.GetEnumerator();
        }

        public int Length
        {
            get { return _matrix.Length; }
        }

        public Position this[int index]
        {
            get { return _matrix[index]; }
            set { _matrix[index] = value; }
        }
    }
}
