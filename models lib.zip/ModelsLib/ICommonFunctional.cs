﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelsLib
{
    public class CommonFunctional<T> where T : struct
    {

    }
    //   https://professorweb.ru/my/csharp/charp_theory/level11/11_9.php


    public class BaseAccount
    {
        object Count;
        public BaseAccount(object _money)
        {
            this.Count = _money;
        }
        public virtual T Info<T>(T calculateCount)
            where T : BaseAccount
        {
            return calculateCount;
        }
    }

    public class UahAccount : BaseAccount
    {
        decimal Count1;
        public UahAccount(decimal _c1) : base(_c1) { }
        
        public override T Info<T>(T calculateCount)
        {
            return base.Info(calculateCount);
        }
    }

    public class UsdAccount : BaseAccount
    {
        int Count1;
        public UsdAccount(int _c1) : base(_c1) { }
    }

}