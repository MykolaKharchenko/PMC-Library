﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelsLib
{
    public class Position : IEnumerable//: List<IPoint>  - так нельзя (слишком просто)  // must be IList<T>????
    {
        private IPoint[] _position;
        // короч, была трабла : конструктор по умоллчанию возвращал массив с ошибкой свойста ДЛИННА . вот я его решил:
        public Position()
        {
            this._position = (IPoint[])Array.CreateInstance(typeof(IPoint), 0);
        }

        public Position(params IPoint[] _collection)
        {
            IPoint[] tempPosition = new IPoint[_collection.Length];
            for (int i = 0; i < _collection.Length; i++)
                tempPosition[i] = _collection[i];
            _position = tempPosition;
        }

        public void AddItem(IPoint newPoint)
        {
            IPoint[] tempPosition = new IPoint[this._position.Length + 1];
            for (int i = 0; i < this._position.Length; i++)
                tempPosition[i] = this._position[i];
            tempPosition[tempPosition.Length - 1] = newPoint;
            this._position = tempPosition;
        }
        public void RemoveItem (int index)
        {
            if (index >= this._position.Length)
                return;

            IPoint[] tempPosition = new IPoint[this._position.Length - 1];
            for (int i = 0, j = 0; i < this._position.Length; i++, j++)
            {
                if (index == i)
                    j--;
                else
                    tempPosition[j] = this._position[i];
            }
            this._position = tempPosition;
        }

        public void ClearAll()
        {
            // как бы здесь вызвать deafault конструтор  ?????   - ответ тут : https://blogs.msdn.microsoft.com/ruericlippert/2010/01/28/1893/
            this._position = (IPoint[])Array.CreateInstance(typeof(IPoint), 0);
        }
        
        public IEnumerator GetEnumerator()
        {
            return _position.GetEnumerator();
        }

        public int Length
        {
            get { return _position.Length; }
        }

        public IPoint this[int index]
        {
            get { return _position[index]; }
            set { _position[index] = value; }
        }
    }

    public class Matrix : IEnumerable
    {
        private Position[] _matrix;

        public Matrix()
        {
            this._matrix = (Position[])Array.CreateInstance(typeof(Position), 0);
        }

        public void AddItem(Position newPosition)
        {
            Position[] tempMatrix = new Position[this._matrix.Length + 1];
            for (int i = 0; i < this._matrix.Length; i++)
                tempMatrix[i] = this._matrix[i];
            tempMatrix[tempMatrix.Length - 1] = newPosition;
            this._matrix = tempMatrix;
        }

        public void RemoveItem(int index)
        {
            if (index >= this._matrix.Length)
                return;

            Position[] tempMatrix = new Position[this._matrix.Length - 1];
            for (int i = 0, j = 0; i < this._matrix.Length; i++, j++)
            {
                if (index == i)
                    j--;
                else
                    tempMatrix[j] = this._matrix[i];
            }
            this._matrix = tempMatrix;
        }

        public void ClearAll()
        {
            this._matrix = (Position[])Array.CreateInstance(typeof(Position), 0);
        }

        public IEnumerator GetEnumerator()
        {
            return _matrix.GetEnumerator();
        }

        public int Length
        {
            get { return _matrix.Length; }
        }

        public Position this[int index]
        {
            get { return _matrix[index]; }
            set { _matrix[index] = value; }
        }
    }

    public class Container : IEnumerable
    {
        private Matrix[] _container;

        public Container()
        {
            this._container = (Matrix[])Array.CreateInstance(typeof(Matrix), 0);
        }

        public void AddItem(Matrix newMatrix)
        {
            Matrix[] tempContainer = new Matrix[this._container.Length + 1];
            for (int i = 0; i < this._container.Length; i++)
                tempContainer[i] = this._container[i];
            tempContainer[tempContainer.Length - 1] = newMatrix;
            this._container = tempContainer;
        }

        public void RemoveItem(int index)
        {
            if (index >= this._container.Length)
                return;

            Matrix[] tempContainer = new Matrix[this._container.Length - 1];
            for (int i = 0, j = 0; i < this._container.Length; i++, j++)
            {
                if (index == i)
                    j--;
                else
                    tempContainer[j] = this._container[i];
            }
            this._container = tempContainer;
        }

        public void ClearAll()
        {
            this._container = (Matrix[])Array.CreateInstance(typeof(Matrix), 0);
        }

        public IEnumerator GetEnumerator()
        {
            return _container.GetEnumerator();
        }

        public int Length
        {
            get { return _container.Length; }
        }

        public Matrix this[int index]
        {
            get { return _container[index]; }
            set { _container[index] = value; }
        }
    }

    public class Containers : IEnumerable
    {
        private Container[] _containers;

        public Containers()
        {
            this._containers = (Container[])Array.CreateInstance(typeof(Container), 0);
        }

        public void AddItem(Container newContainer)
        {
            Container[] tempContainers = new Container[this._containers.Length + 1];
            for (int i = 0; i < this._containers.Length; i++)
                tempContainers[i] = this._containers[i];
            tempContainers[tempContainers.Length - 1] = newContainer;
            this._containers = tempContainers;
        }

        public void RemoveItem(int index)
        {
            if (index >= this._containers.Length)
                return;

            Container[] tempContainers = new Container[this._containers.Length - 1];
            for (int i = 0, j = 0; i < this._containers.Length; i++, j++)
            {
                if (index == i)
                    j--;
                else
                    tempContainers[j] = this._containers[i];
            }
            this._containers = tempContainers;
        }

        public void ClearAll()
        {
            this._containers = (Container[])Array.CreateInstance(typeof(Container), 0);
        }

        public IEnumerator GetEnumerator()
        {
            return _containers.GetEnumerator();
        }

        public int Length
        {
            get { return _containers.Length; }
        }

        public Container this[int index]
        {
            get { return _containers[index]; }
            set { _containers[index] = value; }
        }
    }
}
