﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelsLib
{
    public abstract class CheckingPoint<T>
    {

        /*

        public void Check2()
        {
            object[] values = { (int) 12, (long) 10653, (byte) 12, (sbyte) -5,
                         16.3, "string" };
            foreach (var value in values)
            {
                Type t = value.GetType();
                if (t.Equals(typeof(byte)))
                    Console.WriteLine("{0} is an unsigned byte.", value);
                else if (t.Equals(typeof(sbyte)))
                    Console.WriteLine("{0} is a signed byte.", value);
                else if (t.Equals(typeof(int)))
                    Console.WriteLine("{0} is a 32-bit integer.", value);
                else if (t.Equals(typeof(long)))
                    Console.WriteLine("{0} is a 32-bit integer.", value);
                else if (t.Equals(typeof(double)))
                    Console.WriteLine("{0} is a double-precision floating point.",
                                      value);
                else
                    Console.WriteLine("'{0}' is another data type.", value);
            }

        }

        */
        //public virtual void CheckType()
        public virtual void CheckType(T _x)
        {
            const decimal checkvalue1 = 0;
            const double checkvalue2 = 0;
            const int checkvalue3 = 0;

            Type t = _x.GetType();



            //          if ((typeof(List<DateTime>) == typeof(CheckingPoint<T>)))


        }


    }
}
