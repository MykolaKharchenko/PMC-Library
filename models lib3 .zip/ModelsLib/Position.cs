﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelsLib
{
    public class Position : IEnumerable
    {
        public IPoint[] _position;
        // короч, была трабла : конструктор по умоллчанию возвращал массив с ошибкой свойста ДЛИННА . вот я его решил:
        public Position()
        {
            this._position = (IPoint[])Array.CreateInstance(typeof(IPoint), 0);
        }

        public Position(params IPoint[] _collection)
        {
            IPoint[] tempPosition = new IPoint[_collection.Length];
            for (int i = 0; i < _collection.Length; i++)
                tempPosition[i] = _collection[i];
            _position = tempPosition;
        }

        public void AddItem(IPoint[] thisPosition, IPoint newPoint)
        {
            CommonFunc.AddItem<IPoint>(thisPosition, newPoint);
        }

        public void RemoveItem(int index)
        {
            if (index >= this._position.Length)
                return;

            IPoint[] tempPosition = new IPoint[this._position.Length - 1];
            for (int i = 0, j = 0; i < this._position.Length; i++, j++)
            {
                if (index == i)
                    j--;
                else
                    tempPosition[j] = this._position[i];
            }
            this._position = tempPosition;
        }

        public void ClearAll()
        {
            // как бы здесь вызвать deafault конструтор  ?????   - ответ тут : https://blogs.msdn.microsoft.com/ruericlippert/2010/01/28/1893/

            CommonFunc.DefaultInit(this._position);
            //this._position = (IPoint[])Array.CreateInstance(typeof(IPoint), 0);
        }

        public IEnumerator GetEnumerator()
        {
            return _position.GetEnumerator();
        }

        public int Length
        {
            get { return _position.Length; }
        }

        public IPoint this[int index]
        {
            get { return _position[index]; }
            set { _position[index] = value; }
        }
    }
}
