﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelsLib
{
    public interface IPoint //<U> where U : 
    {
        // пока пустой, 
        // 
        // void CheckTypes<T>(T  _variable);

    }

    public class Point<T> : IPoint //where T : struct
    {
        private readonly T coordX_, coord_Y, coord_Z;//= default(T);       
        private static bool Check = true;
        public Point() { }
        public Point(T x)
        {
            CheckTypes(x);
            if (!Check)
                return;
            this.coordX_ = x;
        }
        public Point(T x, T y)
        {
            CheckTypes(x);
            if (!Check)
                return;
            if (!Check) return;
            this.coordX_ = x;
            this.coord_Y = y;
        }
        public Point(T x, T y, T z)
        {
            CheckTypes(x);
            if (!Check)
                return;
            this.coordX_ = x;
            this.coord_Y = y;
            this.coord_Z = z;
        }

        public void CheckTypes(T _x)
        {
            Type t = _x.GetType();
            if (t.Equals(typeof(Int32)) || t.Equals(typeof(decimal)) || t.Equals(typeof(double))) { }
            else
                Check = false;
        }
    }
}
